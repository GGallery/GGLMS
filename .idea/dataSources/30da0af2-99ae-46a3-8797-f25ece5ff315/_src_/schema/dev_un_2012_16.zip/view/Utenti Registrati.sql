CREATE VIEW `Utenti Registrati` AS
  SELECT
    `u`.`id`            AS `id`,
    `u`.`name`          AS `name`,
    `u`.`username`      AS `username`,
    `u`.`email`         AS `email`,
    `c`.`codicefiscale` AS `codicefiscale`,
    `u`.`registerDate`  AS `registerDate`,
    (SELECT `g`.`title`
     FROM (`dev_un_2012_16`.`un_usergroups` `g`
       JOIN `dev_un_2012_16`.`un_user_usergroup_map` `m`)
     WHERE ((`m`.`user_id` = `u`.`id`) AND (`g`.`id` = `m`.`group_id`) AND (`g`.`id` > 8))
     LIMIT 1)           AS `gruppo`
  FROM (`dev_un_2012_16`.`un_users` `u`
    JOIN `dev_un_2012_16`.`un_users_codicefiscale` `c` ON ((`c`.`id` = `u`.`id`)));
