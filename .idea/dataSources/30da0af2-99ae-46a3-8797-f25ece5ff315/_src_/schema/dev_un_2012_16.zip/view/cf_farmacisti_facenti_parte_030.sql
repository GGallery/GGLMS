CREATE VIEW cf_farmacisti_facenti_parte_030 AS
  SELECT `farmacisti`.`cf` AS `cf`
  FROM ((`dev_un_2012_16`.`un_clienti_unico_030` `zero`
    JOIN `dev_un_2012_16`.`un_clienti_unico` `clienti` ON ((`clienti`.`partita_iva` = `zero`.`partita_iva`))) JOIN
    `dev_un_2012_16`.`un_farmacisti_unico` `farmacisti` ON ((`clienti`.`id` = `farmacisti`.`id_farmacia`)));
